@extends('admin.layouts.master')

@section('content')
    <div class="flex justify-center ">
        <div class="flex flex-col gap-5 p-3 bg-white rounded-lg w-1/2">
            <div class="text-center flex justify-center font-bold text-3xl ">
                <h1>Edit Pengguna</h1>
            </div>
            <div>
                <div class="p-3 shadow-sm rounded-lg">
                    <form method="POST" action="{{ route('user.update', $user->id) }}">
                        @csrf
                        @method('PUT')
                        <div class="form-control w-full mt-4">
                            <label>Name</label>
                            <input id="name" name="name" type="text" class="mt-1 block w-full"
                                value="{{ $user->name }}" required autoFocus autoComplete="name" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Email</label>
                            <input id="email" name="email" type="text" class="mt-1 block w-full"
                                value="{{ $user->email }}" required autoFocus autoComplete="email" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Password</label>
                            <input id="password" name="password" type="password" class="mt-1 block w-full"
                                value='{{ '' }}'' autoFocus autoComplete="password" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Phone Number</label>
                            <input id="phone_number" name="phone_number" type="text" class="mt-1 block w-full"
                                value="{{ $user->phone_number }} "required autoFocus autoComplete="phone_number" />

                            <div class="form-control w-full mt-4">
                                <label>Role</label>
                                <select class="form-control w-full mt-4" name="role" id="role" required
                                    class="mt-1 block w-full p-1">Periode
                                    @forelse ($roles as $role)
                                        <option {{$user->role == $role ? 'selected' : ''}} value="{{ $role->id }}">{{ $role->name }}</option>
                                    @empty
                                        <option value="" default>Pilih Role</option>
                                    @endforelse
                                </select>
                            </div>
                            <div class="flex justify-end">
                                <button type="submit"
                                    class="bg-yellow-500 text-white hover:bg-yellow-600 py-3 px-5 rounded-lg text-md font-semibold m-5 mt-10 w-1/2">
                                    {{ __('Update') }}
                                </button>
                            </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
