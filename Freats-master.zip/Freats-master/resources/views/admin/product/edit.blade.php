@extends('admin.layouts.master')

@section('content')
    <div class="flex justify-center ">
        <div class="flex flex-col gap-5 p-3 bg-white rounded-lg w-1/2">
            <div class="text-center flex justify-center font-bold text-3xl ">
                <h1>Edit Produk</h1>
            </div>
            <div>
                <div class="p-3 shadow-sm rounded-lg">
                    <form method="POST" enctype="multipart/form-data" action="{{ route('product.update', $product->id) }}">
                        @csrf
                        @method('PUT')
                        
                        <div class="form-control w-full mt-4">
                            <label>Name</label>
                            <input id="name" name="name" type="text" class="mt-1 block w-full"
                                value="{{ $product->name }}" required autoFocus autoComplete="name" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Harga</label>
                            <input id="price" name="price" type="number" class="mt-1 block w-full"
                                value="{{ $product->price }}" required autoFocus autoComplete="price" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Produsen</label>
                            <select class="form-control w-full mt-4" name="manufacturer" id="manufacturer" required
                                class="mt-1 block w-full p-1">Periode
                                @forelse ($manufacturers as $manufacturer)
                                    <option {{ $product->manufacturer->id == $manufacturer->id ? 'selected' : '' }} 
                                        value="{{ $manufacturer->id }}">
                                        {{ $manufacturer->name }}
                                    </option>
                                @empty
                                    <option value="" default>Pilih Produsen</option>
                                @endforelse
                            </select>
                        </div>
                        <div class="form-control w-full mt-4">
                            <input id="image" name="image" type="file" class="mt-1 block w-full" autoFocus />
                            <label>Gambar Produk</label>
                            <img src="{{ asset('storage/' . $product->image) }}" alt="" width="100px">
                        </div>
                        <div class="flex justify-end">
                            <button type="submit"
                                class="bg-yellow-500 text-white hover:bg-yellow-600 py-3 px-5 rounded-lg text-md font-semibold m-5 mt-10 w-1/2">
                                {{ __('Update') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
