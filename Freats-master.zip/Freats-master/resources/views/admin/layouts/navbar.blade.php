<nav class="bg-cyan-500 border-b-1 border-b-cyan-600 fixed top-0 left-0 w-full">
    <div class="ml-72 px-6 flex flex-wrap items-center justify-between h-16">
        <a href="" class="flex items-center">
            <span class="self-center text-2xl font-semibold whitespace-nowrap dark:text-white">Freast</span>
        </a>
        <div class="flex md:order-2 gap-3">
             @if (Auth::user())
                <a href="{{ route('logout') }}" onclick="event.preventDefault();
                document.getElementById('logout-form').submit();">
                    <button type="button"
                        class="text-dark font-bold p-2 px-4 rounded-xl ring-2 w-24 bg-gray-200 hover:bg-gray-300">Logout
                    </button>
                </a>
                <form id="logout-form" action="{{ route('logout') }}" method="POST" class="hidden">
                    @csrf
                </form>
            @else
                <a href="{{route('login')}}"">
                    <button type="button"
                        class="text-dark font-bold p-2 px-4 rounded-xl ring-2 w-24 bg-gray-200 hover:bg-gray-300">Login
                    </button>
                </a>
            @endif
        </div>
    </div>
</nav>
