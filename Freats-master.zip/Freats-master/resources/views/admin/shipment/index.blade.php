@extends('admin.layouts.master')

@section('content')
    <div class="flex justify-center ">
        <div class="flex flex-col gap-5 p-3 bg-white rounded-lg">
            <div class="text-center flex justify-center font-bold text-3xl ">
                <h1>Daftar Pengiriman Produk</h1>
            </div>
            <div>
                <div class="p-3 shadow-sm rounded-lg">
                    <form method="POST" enctype="multipart/form-data" action="{{ route('shipment.store') }}">
                        @csrf
                        <div class="form-control w-full mt-4">
                            <label>Produk</label>
                            <select class="form-control w-full mt-4" name="product" id="product" required
                                class="mt-1 block w-full p-1">Periode
                                @forelse ($products as $product)
                                    <option value="{{ $product->id }}">{{ $product->name }}</option>
                                @empty
                                    <option value="" default>Pilih Produk</option>
                                @endforelse
                            </select>
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Distributor</label>
                            <select class="form-control w-full mt-4" name="distributor" id="distributor" required
                                class="mt-1 block w-full p-1">Periode
                                @forelse ($distributors as $distributor)
                                    <option value="{{ $distributor->id }}">{{ $distributor->name }}</option>
                                @empty
                                    <option value="" default>Pilih Distributor</option>
                                @endforelse
                            </select>
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Status</label>
                            <input id="status" name="status" type="text" class="mt-1 block w-full"
                                value="{{ old('status') }}" required autoFocus autoComplete="status" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Kuantitas</label>
                            <input id="quantity" name="quantity" type="number" class="mt-1 block w-full"
                                value="{{ old('quantity') }}" required autoFocus autoComplete="quantity" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Waktu Pengiriman</label>
                            <input id="delivery_date" name="delivery_date" type="date" class="mt-1 block w-full"
                                value="{{ old('delivery_date') }}" required autoFocus autoComplete="delivery_date" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Waktu Sampai</label>
                            <input id="arrival_date" name="arrival_date" type="date" class="mt-1 block w-full"
                                value="{{ old('arrival_date') }}" required autoFocus autoComplete="arrival_date" />
                        </div>
                        <div class="flex justify-end">
                            <button type="submit"
                                class="bg-blue-500 text-white hover:bg-blue-600 py-3 px-5 rounded-lg text-md font-semibold m-5 mt-10 w-1/2">
                                {{ __('Create') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="text-md font-normal ">
                <div class="relative overflow-x-auto">
                    <table class="w-full text-sm text-left text-gray-500">
                        <thead class="text-xs text-gray-700 uppercase bg-blue-300 ">
                            <tr>
                                <th scope="col" class="px-6 py-3">
                                    No
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Produk
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Distributor
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Kuantitas
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Status
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Waktu Pengiriman
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Waktu Sampai
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($shipments as $shipment)
                                <tr class="bg-white border-b">
                                    <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                                        {{ $loop->iteration }}
                                    </th>
                                    <td class="px-6 py-4">
                                        {{ $shipment->product->name }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $shipment->distributor->name }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $shipment->quantity }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $shipment->status }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $shipment->delivery_date }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $shipment->arrival_date }}
                                    </td>
                                    <td class="text-center align-middle">
                                        <div class="flex">
                                            <a href="{{ route('shipment.edit', $shipment->id) }}"
                                                class="bg-yellow-500 text-white hover:bg-yellow-600 py-3 px-5 rounded-lg text-md font-semibold focus:outline-none border-2">
                                                Edit
                                            </a>
                                            <form method="POST" action="{{ route('shipment.destroy', $shipment->id) }}">
                                                @method('delete')
                                                @csrf
                                                <button endpoint="{{ route('shipment.destroy', $shipment->id) }}" type="submit"
                                                    class="bg-red-500 text-white hover:bg-red-600 py-3 px-5 rounded-lg text-md font-semibold focus:outline-none border-2">
                                                    Delete
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection 
