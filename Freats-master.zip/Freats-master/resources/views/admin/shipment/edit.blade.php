@extends('admin.layouts.master')

@section('content')
    <div class="flex justify-center ">
        <div class="flex flex-col gap-5 p-3 bg-white rounded-lg w-1/2">
            <div class="text-center flex justify-center font-bold text-3xl ">
                <h1>Edit Produk</h1>
            </div>
            <div>
                <div class="p-3 shadow-sm rounded-lg">
                    <form method="POST" enctype="multipart/form-data" action="{{ route('shipment.update', $shipment->id) }}">
                        @csrf
                        @method('PUT')

                        <div class="form-control w-full mt-4">
                            <label>Produk</label>
                            <select class="form-control w-full mt-4" name="product" id="product" required
                                class="mt-1 block w-full p-1">Periode
                                @forelse ($products as $product)
                                    <option {{ $shipment->product->id == $product->id ? 'selected' : '' }}
                                        value="{{ $product->id }}">
                                        {{ $product->name }}
                                    </option>
                                @empty
                                    <option value="" default>Pilih Produk</option>
                                @endforelse
                            </select>
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Distributor</label>
                            <select class="form-control w-full mt-4" name="distributor" id="distributor" required
                                class="mt-1 block w-full p-1">Periode
                                @forelse ($distributors as $distributor)
                                    <option {{ $shipment->distributor->id == $distributor->id ? 'selected' : '' }}
                                        value="{{ $distributor->id }}">
                                        {{ $distributor->name }}
                                    </option>
                                @empty
                                    <option value="" default>Pilih Distributor</option>
                                @endforelse
                            </select>
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Status</label>
                            <input id="status" name="status" type="text" class="mt-1 block w-full"
                                value="{{ $shipment->status }}" required autoFocus autoComplete="status" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Kuantitas</label>
                            <input id="quantity" name="quantity" type="number" class="mt-1 block w-full"
                                value="{{ $shipment->quantity }}" required autoFocus autoComplete="quantity" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Waktu Pengiriman</label>
                            <input id="delivery_date" name="delivery_date" type="date" class="mt-1 block w-full"
                                value="{{ $shipment->delivery_Date }}" required autoFocus autoComplete="delivery_date" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Waktu Sampai</label>
                            <input id="arrival_date" name="arrival_date" type="date" class="mt-1 block w-full"
                                value="{{ $shipment->arrival_date }}" required autoFocus autoComplete="arrival_date" />
                        </div>
                        <div class="flex justify-end">
                            <button type="submit"
                                class="bg-yellow-500 text-white hover:bg-yellow-600 py-3 px-5 rounded-lg text-md font-semibold m-5 mt-10 w-1/2">
                                {{ __('Update') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
