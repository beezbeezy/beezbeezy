@extends('admin.layouts.master')

@section('content')
    <div class="flex justify-center">
        <div class="flex flex-col gap-10">
          <div class="text-center  text-5xl font-extrabold">Dashboard</div>
        <div class="relative overflow-x-auto">
            <table class="w-full text-sm text-left text-gray-500">
                <thead class="text-xs text-gray-700 uppercase bg-blue-300 ">
                    <tr>
                        <th scope="col" class="px-6 py-3">
                            No
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Produk
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Distributor
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Kuantitas
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Status
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Waktu Pengiriman
                        </th>
                        <th scope="col" class="px-6 py-3">
                            Waktu Sampai
                        </th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($shipments as $shipment)
                        <tr class="bg-white border-b">
                            <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                                {{ $loop->iteration }}
                            </th>
                            <td class="px-6 py-4">
                                {{ $shipment->product->name }}
                            </td>
                            <td class="px-6 py-4">
                                {{ $shipment->distributor->name }}
                            </td>
                            <td class="px-6 py-4">
                                {{ $shipment->quantity }}
                            </td>
                            <td class="px-6 py-4">
                                {{ $shipment->status }}
                            </td>
                            <td class="px-6 py-4">
                                {{ $shipment->delivery_date }}
                            </td>
                            <td class="px-6 py-4">
                                {{ $shipment->arrival_date }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        </div>
    </div>
@endsection
