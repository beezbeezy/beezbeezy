@extends('admin.layouts.master')

@section('content')
    <div class="flex justify-center ">
        <div class="flex flex-col gap-5 p-3 bg-white rounded-lg">
            <div class="text-center flex justify-center font-bold text-3xl ">
                <h1>Daftar Distributor</h1>
            </div>
            <div>
                <div class="p-3 shadow-sm rounded-lg">
                    <form method="POST" action="{{ route('distributor.store') }}">
                        @csrf
                        <div class="form-control w-full mt-4">
                            <label>Nama Distributor</label>
                            <input id="name" name="name" type="text" class="mt-1 block w-full"
                                value="{{ old('name') }}" required autoFocus autoComplete="name" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Email Distributor</label>
                            <input id="email" name="email" type="text" class="mt-1 block w-full"
                                value="{{ old('email') }}" required autoFocus autoComplete="email" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>No Telepon Distributor</label>
                            <input id="phone_number" name="phone_number" type="text" class="mt-1 block w-full"
                                value="{{ old('phone_number') }} "required autoFocus autoComplete="phone_number" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Alamat Distributor</label>
                            <input id="address" name="address" type="text" class="mt-1 block w-full"
                                value="{{ old('address') }} "required autoFocus autoComplete="address" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Kota Distributor</label>
                            <input id="city" name="city" type="text" class="mt-1 block w-full"
                                value="{{ old('city') }} "required autoFocus autoComplete="city" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Provinsi Distributor</label>
                            <input id="state_province" name="state_province" type="text" class="mt-1 block w-full"
                                value="{{ old('state_province') }} "required autoFocus autoComplete="state_province" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Tanggal Didirikan</label>
                            <input id="foundation_date" name="foundation_date" type="date" class="mt-1 block w-full"
                                value="{{ old('foundation_date') }} "required autoFocus autoComplete="foundation_date" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Akun Distributor</label>
                            <select class="form-control w-full mt-4" name="user" id="user" required
                                class="mt-1 block w-full p-1">Akun
                                @forelse ($users as $item)
                                    <option value="{{ $item->id }}">{{ $item->name }}</option>
                                @empty
                                    <option value="" default>Pilih Akun</option>
                                @endforelse
                            </select>
                        </div>
                        <div class="flex justify-end">
                            <button type="submit"
                                class="bg-blue-500 text-white hover:bg-blue-600 py-3 px-5 rounded-lg text-md font-semibold m-5 mt-10 w-1/2">
                                {{ __('Create') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="text-md font-normal ">
                <div class="relative overflow-x-auto">
                    <table class="w-full text-sm text-left text-gray-500">
                        <thead class="text-xs text-gray-700 uppercase bg-blue-300 ">
                            <tr>
                                <th scope="col" class="px-6 py-3">
                                    No
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Nama Distributor
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Email
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    No Telepon
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Kota
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Provinsi
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Tanggal didirikan
                                </th>
                                <th scope="col" class="px-6 py-3">
                                    Action
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($distributors as $distributor)
                                <tr class="bg-white border-b">
                                    <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap">
                                        {{ $loop->iteration }}
                                    </th>
                                    <td class="px-6 py-4">
                                        {{ $distributor->name }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $distributor->email }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $distributor->phone_number }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $distributor->city }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $distributor->state_province }}
                                    </td>
                                    <td class="px-6 py-4">
                                        {{ $distributor->foundation_date }}
                                    </td>
                                    <td class="text-center align-middle">
                                        <div class="flex">
                                            <a href="{{ route('distributor.edit', $distributor->id) }}"
                                                class="bg-yellow-500 text-white hover:bg-yellow-600 py-3 px-5 rounded-lg text-md font-semibold focus:outline-none border-2">
                                                Edit
                                            </a>
                                            <div endpoint="{{ route('distributor.destroy', $distributor->id) }}"
                                                class="bg-red-500 text-white hover:bg-red-600 py-3 px-5 rounded-lg text-md font-semibold focus:outline-none border-2">
                                                Delete
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
@endsection
