@extends('admin.layouts.master')

@section('content')
    <div class="flex justify-center ">
        <div class="flex flex-col gap-5 p-3 bg-white rounded-lg w-1/2">
            <div class="text-center flex justify-center font-bold text-3xl ">
                <h1>Edit Distributor</h1>
            </div>
            <div>
                <div class="p-3 shadow-sm rounded-lg">
                    <form method="POST" action="{{ route('distributor.update', $distributor->id) }}">
                        @csrf
                        @method('PUT')
                        <div class="form-control w-full mt-4">
                            <label>Nama Distributor</label>
                            <input id="name" name="name" type="text" class="mt-1 block w-full"
                                value="{{ $distributor->name }}" required autoFocus autoComplete="name" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Email Distributor</label>
                            <input id="email" name="email" type="text" class="mt-1 block w-full"
                                value="{{ $distributor->email }}" required autoFocus autoComplete="email" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>No Telepon Distributor</label>
                            <input id="phone_number" name="phone_number" type="text" class="mt-1 block w-full"
                                value="{{ $distributor->phone_number }} "required autoFocus autoComplete="phone_number" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Alamat Distributor</label>
                            <input id="address" name="address" type="text" class="mt-1 block w-full"
                                value="{{ $distributor->address }} "required autoFocus autoComplete="address" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Kota Distributor</label>
                            <input id="city" name="city" type="text" class="mt-1 block w-full"
                                value="{{ $distributor->city }} "required autoFocus autoComplete="city" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Provinsi Distributor</label>
                            <input id="state_province" name="state_province" type="text" class="mt-1 block w-full"
                                value="{{ $distributor->state_province }} "required autoFocus
                                autoComplete="state_province" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Tanggal Didirikan</label>
                            <input id="foundation_date" name="foundation_date" type="date" class="mt-1 block w-full"
                                value="{{ $distributor->foundation_date }} "required autoFocus
                                autoComplete="foundation_date" />
                        </div>
                        <div class="form-control w-full mt-4">
                            <label>Akun Distributor</label>
                            <select class="form-control w-full mt-4" name="user" id="user" required
                                class="mt-1 block w-full p-1">Akun
                                @forelse ($users as $item)
                                    <option {{ $distributor->user == $item ? 'selected' : '' }} value="{{ $item->id }}">
                                        {{ $item->name }}
                                    </option>
                                @empty
                                    <option value="" default>Pilih Akun</option>
                                @endforelse
                            </select>
                        </div>
                        <div class="flex justify-end">
                            <button type="submit"
                                class="bg-yellow-500 text-white hover:bg-yellow-600 py-3 px-5 rounded-lg text-md font-semibold m-5 mt-10 w-1/2">
                                {{ __('Update') }}
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
