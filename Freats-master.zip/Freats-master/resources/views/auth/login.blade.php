@extends('layouts.master')

@section('content')
    <div class="flex justify-center h-auto my-20    ">
        <div class="flex flex-col w-1/2">
            <div class="text-center text-4xl font-extrabold">Login</div>
            <div class="flex justify-center w-full">
                <form action="{{ route('login') }}" method="post" class="flex flex-col gap-4 w-full">
                    @csrf
                    <div class="flex flex-col gap-2  w-full">
                        <label for="email">Email</label>
                        <input type="email" name="email" id="email" class="border-2 rounded-md p-2  w-full" value="{{ old('email') }}">
                        @error('email')
                            <div class="text-red-500">{{ $message }}</div>
                        @enderror
                    </div>
                    <div class="flex flex-col gap-2">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="border-2 rounded-md p-2">
                        @error('password')
                            <div class="text-red-500">{{ $message }}</div>
                        @enderror
                    </div>
                    <button type="submit" class="bg-blue-500 text-white rounded-md p-2 w-1/2 m-auto">Login</button>
                </form>
            </div>
        </div>
    </div>
@endsection
