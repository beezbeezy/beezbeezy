@extends('admin.layouts.master')

@section('content')
<div class="flex text-5xl font-extrabold">
  <h1>Hello world!</h1>
</div>
@endsection
