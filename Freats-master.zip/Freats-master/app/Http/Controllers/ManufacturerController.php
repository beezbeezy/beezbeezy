<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Manufacturer;
use App\Models\User;
use Illuminate\Http\Request;

class ManufacturerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $users = User::all();
        $manufacturers = Manufacturer::all();
        return view('admin.manufacturer.index', compact(['users', 'manufacturers']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $manufacturer = Manufacturer::create([
            'user_id' => $request->user,
            'name' => $request->name,
            'email' => $request->email,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'city' => $request->city,
            'state_province' => $request->state_province,
            'foundation_date' => $request->foundation_date,
        ]);
        return redirect()->route('manufacturer.index')->with('success', 'Manufacturer created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $manufacturer = Manufacturer::find($id);
        $users = User::all();
        return view('admin.manufacturer.edit', compact(['manufacturer', 'users']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $manufacturer = Manufacturer::find($id);
        $manufacturer->update([
            'user_id' => $request->user,
            'name' => $request->name,
            'email' => $request->email,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'city' => $request->city,
            'state_province' => $request->state_province,
            'foundation_date' => $request->foundation_date,
        ]);
        return redirect()->route('manufacturer.index')->with('success', 'Manufacture updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $manufacturer = Manufacturer::find($id);
        $manufacturer->delete();
        return redirect()->route('manufacturer.index')->with('success', 'Manufacture deleted successfully');
    }
}
