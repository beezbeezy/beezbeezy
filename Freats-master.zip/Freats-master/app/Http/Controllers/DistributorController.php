<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Distributor;
use App\Models\User;
use Illuminate\Http\Request;

class DistributorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $users = User::all();
        $distributors = Distributor::all();
        return view('admin.distributor.index', compact(['users', 'distributors']));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $distributor = Distributor::create([
            'user_id' => $request->user,
            'name' => $request->name,
            'email' => $request->email,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'city' => $request->city,
            'state_province' => $request->state_province,
            'foundation_date' => $request->foundation_date,
        ]);
        return redirect()->route('distributor.index')->with('success', 'Distributor created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $distributor = Distributor::find($id);
        $users = User::all();
        return view('admin.distributor.edit', compact(['distributor', 'users']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $distributor = Distributor::find($id);
        $distributor->update([
            'user_id' => $request->user,
            'name' => $request->name,
            'email' => $request->email,
            'phone_number' => $request->phone_number,
            'address' => $request->address,
            'city' => $request->city,
            'state_province' => $request->state_province,
            'foundation_date' => $request->foundation_date,
        ]);
        return redirect()->route('distributor.index')->with('success', 'Distributor updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        $distributor = Distributor::find($id);
        $distributor->delete();
        return redirect()->route('distributor.index')->with('success', 'Distributor deleted successfully');
    }
}
