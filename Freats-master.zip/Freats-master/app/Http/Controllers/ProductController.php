<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\File;
use App\Models\Manufacturer;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $manufacturers = Manufacturer::all();
        $products = Product::with('manufacturer')->get();
        return view('admin.product.index', compact(['manufacturers', 'products']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $file = Storage::disk('public')->put('product', $request->file('image'));
        $product = Product::create([
            'name' => $request->name,
            'price' => $request->price,
            'manufacturer_id' => $request->manufacturer,
            'image' => $file,
        ]);
        return redirect()->route('product.index')->with('success', 'Product created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $manufacturers = Manufacturer::all();
        $product = Product::with('manufacturer')->find($id);
        return view('admin.product.edit', compact(['manufacturers', 'product']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
        $product = Product::find($id);
        $product->name = $request->name;
        $product->price = $request->price;
        $product->manufacturer_id = $request->manufacturer;
        if ($request->hasFile('image'))
        {
            Storage::disk('public')->delete($product->image);
            $file = Storage::disk('public')->put('product', $request->file('image'));
            $product->image = $file;
        }
        $product->save();
        return redirect()->route('product.index')->with('success', 'Product updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
        //
        $product = Product::find($id);
        $product->delete();
        Storage::disk('public')->delete($product->image);
        return redirect()->route('product.index')->with('success', 'Product deleted successfully');
    }
}
