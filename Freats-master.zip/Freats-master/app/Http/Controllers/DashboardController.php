<?php

namespace App\Http\Controllers;

use App\Models\Shipment;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    //
    public function index()
    {
        $shipments = Shipment::with('distributor', 'product')->get();
        return view('admin.dashboard', compact(['shipments']));
    }

    public function home()
    {
        $shipments = Shipment::with('distributor', 'product')->get();
        return view('home', compact(['shipments']));
    }
}
