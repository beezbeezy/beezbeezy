<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Shipment;
use App\Models\Distributor;
use App\Models\Product;
use Illuminate\Http\Request;

class ShipmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
        $shipments = Shipment::with('distributor', 'product')->get();
        $distributors = Distributor::all();
        $products = Product::all();

        return view('admin.shipment.index', compact(['shipments', 'distributors', 'products']));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $shipment = Shipment::create([
            'distributor_id' => $request->distributor,
            'product_id' => $request->product,
            'quantity' => $request->quantity,
            'delivery_date' => $request->delivery_date,
            'status' => $request->status,
            'arrival_date' => $request->arrival_date,
        ]);

        return redirect()->route('shipment.index')->with('success', 'Shipment created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
        $shipment = Shipment::with('distributor', 'product')->find($id);
        $distributors = Distributor::all();
        $products = Product::all();

        return view('admin.shipment.edit', compact(['shipment', 'distributors', 'products']));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

}
